# Table of Contents

- [Mobile](#mobile)
  - New game / Play / Help / Leaderboard page
  - 404 page

- [Desktop](#desktop)
  - New game / Play / Help / Leaderboard page
  - 404 page

<br>

# Mobile

### New game / Play / Help / Leaderboard page

  ![New game / Play / Help / Leaderboard page](testing/performance/mobile-index.png)

### 404 page

  ![404 page](testing/performance/mobile-404.png)

<br>

# Desktop

### New game / Play / Help / Leaderboard page

  ![New game / Play / Help / Leaderboard page](testing/performance/desktop-index.png)

### 404 page

  ![404 page](testing/performance/desktop-404.png)

[Back To **Table of Contents**](#table-of-contents)